using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlimeController : MonoBehaviour
{

    public float _moveSpeedSlime = 3.5f;
    private Vector2 _slimeDirection;
    private Rigidbody2D _slimeRB2D;

    public DetectionController _detectionArea;
    private SpriteRenderer _spriteRenderer;

    // Start is called before the first frame update
    void Start()
    {
        _slimeRB2D = GetComponent<Rigidbody2D>();
        _spriteRenderer = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        _slimeDirection = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
    }

    public float Health
    {
        set
        {
            Health = value;
            if(health <= 0)
            {
                Dead();
            }
        }
        get 
        { 
            return Health; 
        }
    }


    public float health = 1;

    public void TakeDamage (float damage)
    {
        health -= damage;
    }

    public void Dead () 
    { 
        Destroy(gameObject);
    }

    private void FixedUpdate()
    {
        if (_detectionArea.detectedObjs.Count > 0)
        {
            _slimeDirection = (_detectionArea.detectedObjs[0].transform.position - transform.position).normalized;

            _slimeRB2D.MovePosition(_slimeRB2D.position + _slimeDirection * _moveSpeedSlime * Time.fixedDeltaTime);

            if (_slimeDirection.x > 0) 
            {
                _spriteRenderer.flipX = false;
            }

            else if(_slimeDirection.x < 0) 
            {
                _spriteRenderer.flipX = true;
            }
        }

    }
}
