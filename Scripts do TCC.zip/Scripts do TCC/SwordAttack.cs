using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwordAttack : MonoBehaviour
{
    [SerializeField]public Collider2D swordCollider;
    [SerializeField]public float damage = 3;
    [SerializeField]public float attackTime = 0.3f;

    private void Start() 
    {
        swordCollider.enabled = false;
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Attack();
        }
    }
    public void Attack() 
    {
        swordCollider.enabled = true;
        StartCoroutine(StopAttack(attackTime));
    }

    IEnumerator StopAttack(float duration) 
    {
        yield return new WaitForSeconds(duration);
        swordCollider.enabled = false;
    }

    
}
